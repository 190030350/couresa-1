package io.github.zutherb.appstash.shop.service.cart.domain

class CartItem implements Serializable {
    def String uuid;
    def Product product;
}
