install.packages("recommenderlab", repos="http://cran.fhcrc.org", dependencies = TRUE)
install.packages("rjson", repos="http://cran.fhcrc.org", dependencies = TRUE)