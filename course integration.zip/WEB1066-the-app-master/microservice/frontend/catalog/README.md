# How to install this app?

bower install
npm install

grunt serve
