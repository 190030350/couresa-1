#!/bin/sh
kubectl delete rc,pods,service --all --namespace=default
