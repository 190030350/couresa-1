#!/bin/sh
KUBE_AWS_ZONE=eu-west-1c KUBERNETES_PROVIDER=aws kubernetes/cluster/kube-down.sh