#!/bin/sh
cd vagrant
NUM_INSTANCES=3 vagrant halt
cd ..