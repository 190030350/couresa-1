package io.github.zutherb.appstash.shop.service.cart.api;

public interface Cart extends CartFulfillmentProvider { /* marker interface for the cart */ }
