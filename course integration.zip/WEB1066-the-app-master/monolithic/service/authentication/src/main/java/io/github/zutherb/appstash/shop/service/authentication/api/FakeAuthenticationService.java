package io.github.zutherb.appstash.shop.service.authentication.api;

/**
 * @author zutherb
 */
public interface FakeAuthenticationService {
    boolean authenticate();
}
